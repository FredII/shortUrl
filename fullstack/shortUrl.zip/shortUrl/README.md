## 短域名服务

## 目录结构

```
├── README.md                        // 简要说明
├── config                           // 配置文件夹
│   ├── db.js                        // MongoDB数据库配置
│   └── default.json                 // 默认链接配置
├── package-lock.json
├── package.json
├── api                              // API层
│   ├── urlLongToShort.js            // 长域名转换成短域名接口
│   └── urlShortToLong.js            // 短域名重定向长域名接口
├── coverage                         // 单元测试覆盖率配置文件目录
│  
├── models                           // 数据库操作
│   └── url.js                       // NoSQL的Schema配置
├── others                           // 附件包
│   ├── 集成测试案例短域名服务演示.mov   // 集成测试案例短域名服务演示录屏
│   ├── 简单框架设计图.png             // 简单框架设计图
│   └── 单元测试及测试覆盖率.png        // Jest单元测试及测试覆盖率截图
├── routes                           // 路由层
│   └── index.js                     // 统一的路由分发配置
├── utils                            // 工具包
│   └── tool.js                      // 统一的工具函数集中定义
├── app.js                           // 服务入口文件
├── jest.config.js                   // Jest测试配置文件
├── testServer.js                    // API接口测试服务，需要使用Supertest
└── unit.test.js                     // Jest单元测试文件
```

## 启服务

```shell
# 本地开发调试启动命令，会用到nodemon
npm run dev

# 本地Jest单元测试启动命令，会伴随生成单元测试覆盖率报告
npm run test

# 启动线上服务命令
npm run server

```
