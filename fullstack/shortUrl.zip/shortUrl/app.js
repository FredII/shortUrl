/**
 * app.js
 * @authors lizilong
 * @date    2022-05-10
 * @description 服务主文件
 */
const express = require('express')
const bodyParser = require('body-parser')
const connectDB = require('./config/db')

const app = express()

// 设置后Post接口方可获取到Body中的参数
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))

// 连接MongoDB
connectDB()

app.use(
	express.json({
		extended: false,
	})
)

// 设置端口
app.set('port', process.env.PORT || 3000)

// 统一的路由分发
var routes = require('./routes/index')
routes(app)

// 启动服务的时候监听端口号
app.listen(app.get('port'), () => {
	console.log('Server listening on port:', app.get('port'))
})

module.exports = app
