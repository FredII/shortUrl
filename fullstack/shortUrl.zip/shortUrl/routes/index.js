/**
 * index.js
 * @authors lizilong
 * @date    2022-05-10
 * @description 总的路由控制文件
 */

const urlLongToShort = require('../api/urlLongToShort')
const urlShortToLong = require('../api/urlShortToLong')
module.exports = (app) => {
	app.use('/', urlShortToLong)
	app.use('/api/urlLongToShort', urlLongToShort)
}
