// 对api接口测试需要使用supertest，使用expert断言，supertest是一个非常好的适用于node的模拟http请求的库
const request = require('supertest')
// 引入产生请求的程序入口app.js
const server = require('./app')

module.exports = request(server)
